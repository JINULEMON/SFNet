import torch
import torch.nn as nn
import torch.nn.functional as F
from torchstat import stat
import ptflops

from ptflops import get_model_complexity_info
class FireModule(nn.Module):
    def __init__(self, in_planes, squeeze_planes, expand1x1_planes, expand3x3_planes):
        super(FireModule, self).__init__()
        self.squeeze = nn.Conv2d(in_planes, squeeze_planes, kernel_size=1)
        self.squeeze_activation = nn.ReLU(inplace=True)
        self.expand1x1 = nn.Conv2d(squeeze_planes, expand1x1_planes, kernel_size=1)
        self.expand1x1_activation = nn.ReLU(inplace=True)
        self.expand3x3 = nn.Conv2d(squeeze_planes, expand3x3_planes, kernel_size=3, padding=1)
        self.expand3x3_activation = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.squeeze_activation(self.squeeze(x))
        return torch.cat([
            self.expand1x1_activation(self.expand1x1(x)),
            self.expand3x3_activation(self.expand3x3(x))
        ], 1)


class SqueezeNet(nn.Module):
    def __init__(self, num_classes=1000):
        super(SqueezeNet, self).__init__()
        self.features1 =  nn.Sequential(
            nn.Conv2d(3, 96, kernel_size=7, stride=2, padding=3),
            nn.ReLU(inplace=True))
        self.features2 = nn.Sequential(
            nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True),
            FireModule(96, 16, 64, 64),
            FireModule(128, 16, 64, 64),
            FireModule(128, 32, 128, 128))
        self.features3 = nn.Sequential(
            nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True),
            FireModule(256, 32, 128, 128),
            FireModule(256, 48, 192, 192),
            FireModule(384, 48, 192, 192),
            FireModule(384, 64, 256, 256))


    def forward(self, x):
        x1 = self.features1(x)
        x2 = self.features2(x1)
        x3 = self.features3(x2)

        return x1,x2,x3




# model = SqueezeNet(num_classes=1000)
#
# x=torch.randn(1,3,224,224)
# out1,out2,out3=model(x)
# print(out1.shape)
# print(out2.shape)
# print(out3.shape)

from einops import rearrange
from torch.nn import *
from mmcv.cnn import build_activation_layer, build_norm_layer
from timm.models.layers import DropPath
from einops.layers.torch import Rearrange
import numpy as np
import torch
from torch.nn import Module, ModuleList, Upsample
from mmcv.cnn import ConvModule
from torch.nn import Sequential, Conv2d, UpsamplingBilinear2d
import torch.nn as nn



class BNPReLU(nn.Module):
    def __init__(self, nIn):
        super().__init__()
        self.bn = nn.BatchNorm2d(nIn, eps=1e-3)
        self.acti = nn.PReLU(nIn)

    def forward(self, input):
        output = self.bn(input)
        output = self.acti(output)

        return output





class MLP(nn.Module):
    """
    Linear Embedding
    """

    def __init__(self, input_dim=64, embed_dim=128):
        super().__init__()
        self.proj = nn.Linear(input_dim, embed_dim)

    def forward(self, x):
        x = x.flatten(2).transpose(1, 2)
        x = self.proj(x)
        return x

def resize(input,
           size=None,
           scale_factor=None,
           mode='nearest',
           align_corners=None,
           warning=True):
    if warning:
        if size is not None and align_corners:
            input_h, input_w = tuple(int(x) for x in input.shape[2:])
            output_h, output_w = tuple(int(x) for x in size)
            if output_h > input_h or output_w > output_h:
                if ((output_h > 1 and output_w > 1 and input_h > 1
                     and input_w > 1) and (output_h - 1) % (input_h - 1)
                        and (output_w - 1) % (input_w - 1)):
                    warnings.warn(
                        f'When align_corners={align_corners}, '
                        'the output would more aligned if '
                        f'input size {(input_h, input_w)} is `x+1` and '
                        f'out size {(output_h, output_w)} is `nx+1`')
    return F.interpolate(input, size, scale_factor, mode, align_corners)

class conv(nn.Module):
    """
    Linear Embedding
    """

    def __init__(self, input_dim=64, embed_dim=128):
        super().__init__()

        '''
        self.proj = nn.Sequential(nn.Conv2d(input_dim, embed_dim, 3, padding=1, bias=False), nn.ReLU(),
                                  nn.Conv2d(embed_dim, embed_dim, 3, padding=1, bias=False), nn.ReLU())
        '''
        self.proj = nn.Sequential(nn.Conv2d(input_dim, embed_dim, 1, padding=0, bias=False), nn.ReLU())

    def forward(self, x):
        x = self.proj(x)
        # x = x.flatten(2).transpose(1, 2)  #X的size为[B,N,H,W]flatten为[B,N,H*W]再transpose为[B,H*W,N]
        return x

class FilterHigh(nn.Module):
    def __init__(self, recursions=1, kernel_size=5, stride=1, padding=True, include_pad=True, normalize=True,
                 gaussian=False):
        super(FilterHigh, self).__init__()
        if padding:
            pad = int((kernel_size - 1) / 2)
        else:
            pad = 0
        self.filter_low = nn.MaxPool2d(kernel_size=kernel_size, stride=stride, padding=pad)
        # count_include_pad - 如果等于True，计算平均池化时，将包括padding填充的0
        self.recursions = recursions
        self.normalize = normalize

    def forward(self, img):

        img = self.filter_low(img) - img
        return img

class segmenthead(nn.Module):

    def __init__(self, inplanes, interplanes, outplanes, scale_factor=2):
        super(segmenthead, self).__init__()
        self.bn1 = nn.BatchNorm2d(inplanes)
        self.conv1 = nn.Conv2d(inplanes, interplanes, kernel_size=3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(interplanes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(interplanes, outplanes, kernel_size=1, padding=0, bias=True)
        self.scale_factor = scale_factor

    def forward(self, x):
        x = self.conv1(self.relu(self.bn1(x)))
        out = self.conv2(self.relu(self.bn2(x)))

        if self.scale_factor is not None:
            height = x.shape[-2] * self.scale_factor
            width = x.shape[-1] * self.scale_factor
            out = F.interpolate(out,
                                size=[height, width],
                                mode='bilinear')

        return out


class Decoder(Module):
    """
    SegFormer: Simple and Efficient Design for Semantic Segmentation with Transformers
    """

    def __init__(self, dims, dim, class_num=3):
        super(Decoder, self).__init__()
        self.num_classes = class_num

        c1_in_channels, c2_in_channels, c3_in_channels = dims[0], dims[1], dims[2]
        embedding_dim = dim

        #self.CFP_1 = CFPModule1(32, d=8)


        self.linear_c3 = conv(input_dim=c3_in_channels, embed_dim=embedding_dim)
        self.linear_c2 = conv(input_dim=c2_in_channels, embed_dim=embedding_dim)
        self.linear_c1 = conv(input_dim=c1_in_channels, embed_dim=embedding_dim)

        self.linear_fuse = ConvModule(in_channels=embedding_dim * 4, out_channels=embedding_dim, kernel_size=1,
                                      norm_cfg=dict(type='BN', requires_grad=True))

        self.linear_fuse2 = ConvModule(in_channels=embedding_dim * 2, out_channels=embedding_dim, kernel_size=1,
                                       norm_cfg=dict(type='BN', requires_grad=True))
        self.linear_fuse1 = ConvModule(in_channels=embedding_dim * 2, out_channels=embedding_dim, kernel_size=1,
                                       norm_cfg=dict(type='BN', requires_grad=True))

        self.linear_pred = Conv2d(embedding_dim, self.num_classes, kernel_size=1)
        self.dropout = nn.Dropout(0.1)

        self.filter = FilterHigh(recursions=1, stride=1, kernel_size=5, include_pad=True,
                                 gaussian=False, normalize=False)
        self.linear_predhigh = segmenthead(256, 64, 3)
        self.linear_predlow = segmenthead(256, 64, 3)
        self.sigmoid1 = nn.Sigmoid()

    def forward(self, inputs):
        c1, c2, c3 = inputs
        ############## MLP decoder on C1-C4 ###########
        n, _, h, w = c3.shape



        _c3 = self.linear_c3(c3)
        #_c3 = self.CFP_1(_c3)
        _c3 = resize(_c3, size=c1.size()[2:], mode='bilinear', align_corners=False)
        # _c2 = self.linear_c2(c2).permute(0, 2, 1).reshape(n, -1, c2.shape[2], c2.shape[3])
        _c2 = self.linear_c2(c2)
        #_c2 = self.CFP_1(_c2)
        _c2 = resize(_c2, size=c1.size()[2:], mode='bilinear', align_corners=False)
        # _c1 = self.linear_c1(c1).permute(0, 2, 1).reshape(n, -1, c1.shape[2], c1.shape[3])
        _c1 = self.linear_c1(c1)


        L2 = self.linear_fuse2(torch.cat([_c3, _c2], dim=1))
        _c = self.linear_fuse1(torch.cat([L2, _c1], dim=1))

        #        _c = self.linear_fuse(torch.cat([_c4, _c3, _c2, _c1], dim=1))
        xhigh = self.filter(_c)
        xhigh = self.linear_predhigh(xhigh)
        xlow = self.linear_predlow(_c)
        attnhigh = self.sigmoid1(xhigh)

        x = xlow + xlow * attnhigh
        return xhigh, x

class ssa_PLD(nn.Module):
    def __init__(self, class_num=3, **kwargs):
        super(ssa_PLD, self).__init__()
        self.class_num = class_num
        ######################################load_weight
        self.backbone = SqueezeNet()
        #####################################
        self.decode_head = Decoder(dims=[96, 256, 512], dim=256, class_num=class_num)
        #self.decode_head = Decoder(class_num=class_num)

    def forward(self, _input):
        x = _input[:, 0:3, :, :]
        loc = _input[:, 3, :, :].unsqueeze(1)
        features = self.backbone(x)

        featureshigh, featureslow = self.decode_head(features)
        # up = UpsamplingBilinear2d(scale_factor=4)
        # features = up(features)
        return {
            # 'coarse_masks': [x_extra_p, x_extra_d],
            'pred_edges': [featureshigh],
            'pred_masks': [featureslow],
            # 'pred_locs': [loc]
        }

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, (nn.BatchNorm2d,nn.LayerNorm)):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()
if __name__ == '__main__':
    model = ssa_PLD(3)
    total = sum([param.nelement() for param in model.parameters()])
    print("Number of parameter: %.2fM" % (total / 1e6))
    #stat(model, (4, 384, 384))
    input = torch.rand(1, 4, 384, 384)
    # stat(model, (4, 640, 480))
    flops, params = get_model_complexity_info(model, (4, 640, 480), as_strings=True,
                                              print_per_layer_stat=True)  # (3,512,512)输入图片的尺寸
    print("Flops: {}".format(flops))
    print("Params: " + params)


    outs = model(input)
    outs = outs['pred_masks']

    #print(outs.shape)

    for feature_map in outs:
        print(feature_map.shape)

