# -*- coding: utf-8 -*-
import numpy as np
import cv2
from PIL import Image
import os
import sys

sys.path.append('/data/home/xc')

def find_circle(input_image):

    contours, hierarchy = cv2.findContours(input_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    max_area = 0
    max_idx = 0
    if len(contours) == 0:
        ellipse = (0, 0), (0, 0), 0
        return ellipse, contours, max_idx
    for idx, contour in enumerate(contours):
        area = cv2.contourArea(contour)
        if area > max_area:
            max_idx = idx
            max_contour = contour
            max_area = area

    ellipse = cv2.fitEllipse(max_contour)

    return ellipse, contours, max_idx


if __name__ == "__main__":
    model_name = 'biffnet'
    # dataset = 'CASIA-Iris-Mobile-V1.0'
    # dataset = 'CASIA-Iris-Africa'
    # dataset = 'CASIA-Iris-Complex-Occlusion'
    # dataset = 'CASIA-Iris-Complex-Off-Angle'
    # dataset = 'CASIA-Iris-Distance'
    dataset = 'MICHE'
    # dataset = 'distance'
    vis = True

    outer_circle_dir = os.path.join('./results/', dataset, model_name, "Outer_Boundary")
    inner_circle_dir = os.path.join('./results/', dataset, model_name, "Inner_Boundary")
    #vis_circle_dir = os.path.join('./results/', dataset, model_name, "result_vis_circle")
    vis_circle_dir = os.path.join('/data/home/xc/experiments/MICHE-EdgeViTpyramidd3decoderCAweightbce_20221015_012919_logging/checkpoints/test/', "result_vis_circle")
    outer_circle_dir_dice = os.path.join('./results/', dataset, model_name, 'Outer_Circle')
    inner_circle_dir_dice = os.path.join('./results/', dataset, model_name, 'Inner_Circle')


    if not os.path.exists(outer_circle_dir):
        os.makedirs(outer_circle_dir)
    if not os.path.exists(inner_circle_dir):
        os.makedirs(inner_circle_dir)
    if not os.path.exists(vis_circle_dir):
        os.makedirs(vis_circle_dir)
    if not os.path.exists(outer_circle_dir_dice):
        os.makedirs(outer_circle_dir_dice)
    if not os.path.exists(inner_circle_dir_dice):
        os.makedirs(inner_circle_dir_dice)
    #test_dir = os.path.join('./data/' + dataset + '/img_dir/val')
    test_dir = os.path.join('/data/home/xc/biFFNet/data/data/' + dataset + '/img_dir/val')
    #out_dir_outer = os.path.join('./results/', dataset, model_name, 'result_outer')
    #out_dir_inner = os.path.join('./results/', dataset, model_name, 'result_inner')
    out_dir_outer = os.path.join('/data/home/xc/experiments/MICHE-EdgeViTpyramidd3decoderCAweightbce_20221015_012919_logging/checkpoints/test/', 'iris_edge_mask_raw')
    out_dir_inner = os.path.join('/data/home/xc/experiments/MICHE-EdgeViTpyramidd3decoderCAweightbce_20221015_012919_logging/checkpoints/test/', 'pupil_edge_mask_raw')
    img_list = os.listdir(out_dir_outer)
    if dataset == 'CASIA-Iris-Africa':
        pix = '.JPEG'
    if dataset == 'CASIA-Iris-Mobile-V1.0':
        pix = '.JPG'
    if dataset == 'CASIA-Iris-Complex-Occlusion':
        pix = '.jpg'
    if dataset == 'CASIA-Iris-Complex-Off-Angle':
        pix = '.jpg'
    if dataset == 'CASIA-Iris-Distance':
        pix = '.JPEG'
    if dataset == 'distance':
        pix = '.JPEG'
    if dataset == 'MICHE':
        pix = '.JPEG'
    for idx, i in enumerate(img_list):
        print(i)
        img_name = i[:-4] + pix
        print(img_name)
        image = cv2.imread(os.path.join(test_dir, img_name))
        outer = cv2.imread(os.path.join(out_dir_outer, i), cv2.IMREAD_GRAYSCALE)
        inner = cv2.imread(os.path.join(out_dir_inner, i), cv2.IMREAD_GRAYSCALE)
        image_outer = np.zeros_like(outer)
        image_inner = np.zeros_like(inner)
        image_outer_circle = np.zeros_like(outer)
        image_inner_circle = np.zeros_like(inner)

        outer_circle, outer_contours, outer_idx = find_circle(outer)
        inner_circle, inner_contours, inner_idx = find_circle(inner)

        image = cv2.ellipse(image, outer_circle, (0, 255, 0), 1)
        image = cv2.ellipse(image, inner_circle, (0, 0, 255), 1)
        image = cv2.drawContours(image, outer_contours, outer_idx, (255, 0, 0), 1)
        image = cv2.drawContours(image, inner_contours, inner_idx, (255, 0, 0), 1)

        image_outer = cv2.ellipse(image_outer, outer_circle, 255, 1)
        image_inner = cv2.ellipse(image_inner, inner_circle, 255, 1)
        image_outer_circle = cv2.ellipse(image_outer_circle, outer_circle, 255, -1)
        image_inner_circle = cv2.ellipse(image_inner_circle, inner_circle, 255, -1)

        image_outer = Image.fromarray(image_outer)
        image_inner = Image.fromarray(image_inner)
        image_outer_circle = Image.fromarray(image_outer_circle)
        image_inner_circle = Image.fromarray(image_inner_circle)

        image_outer = image_outer.convert('L')
        image_outer_circle = image_outer_circle.convert('L')
        image_inner = image_inner.convert('L')
        image_inner_circle = image_inner_circle.convert('L')

        outer_path = os.path.join(outer_circle_dir, i)
        inner_path = os.path.join(inner_circle_dir, i)

        vis_path = os.path.join(vis_circle_dir, img_name)

        image_outer.save(outer_path)
        image_inner.save(inner_path)
        image_outer_circle.save(os.path.join(outer_circle_dir_dice, i))
        image_inner_circle.save(os.path.join(inner_circle_dir_dice, i))
        cv2.imwrite(vis_path, image)
